def my_other_method():
    """This is a
    multi-line
    descriptive
    docstring."""
    print("Called my_other_method.")


help(my_other_method)
