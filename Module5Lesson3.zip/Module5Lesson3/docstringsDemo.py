#help(dir)
print(dir.__doc__)